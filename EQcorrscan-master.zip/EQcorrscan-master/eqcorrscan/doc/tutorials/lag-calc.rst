Lag time calculation and pick correction - Unfinished
=====================================================

To be completed
