sac_util
--------

.. currentmodule:: eqcorrscan.utils.sac_util
.. automodule:: eqcorrscan.utils.sac_util

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       sactoevent

    .. comment to end block
