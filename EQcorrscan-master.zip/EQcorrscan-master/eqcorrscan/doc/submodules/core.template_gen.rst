template_gen
------------

.. currentmodule:: eqcorrscan.core.template_gen
.. automodule:: eqcorrscan.core.template_gen

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       _template_gen
       extract_from_stack
       from_client
       from_contbase
       from_quakeml
       from_sac
       from_seishub
       from_sfile
       multi_template_gen
       

    .. comment to end block
