stacking
--------

.. currentmodule:: eqcorrscan.utils.stacking
.. automodule:: eqcorrscan.utils.stacking

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       linstack
       PWS_stack
       align_traces

    .. comment to end block
