synth_seis
----------

.. currentmodule:: eqcorrscan.utils.synth_seis
.. automodule:: eqcorrscan.utils.synth_seis

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       generate_synth_data
       seis_sim
       SVD_sim
       template_grid

    .. comment to end block
