despike
-------

.. currentmodule:: eqcorrscan.utils.despike
.. automodule:: eqcorrscan.utils.despike

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       median_filter
       template_remove

    .. comment to end block
